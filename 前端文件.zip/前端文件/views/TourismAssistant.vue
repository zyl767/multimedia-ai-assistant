<template>
  <div class="tourism-assistant">
    <header class="header">
      <div class="header-content">
        <h1>🌍 旅游推荐助手</h1>
        <p>智能问答 · 文档上传 · 知识库检索</p>
      </div>
      <div class="header-stats">
        <span class="stats-item">文档数: {{ documentCount }}</span>
      </div>
    </header>

    <div class="main-content">
      <aside class="sidebar">
        <div class="sidebar-section">
          <h3>📁 上传文档</h3>
          <div class="upload-area" @click="triggerFileInput" @dragover.prevent @drop.prevent="handleDrop">
            <input 
              ref="fileInputRef" 
              type="file" 
              multiple 
              accept=".txt,.docx,.pdf" 
              class="file-input"
              @change="handleFileSelect"
            />
            <div class="upload-icon">📤</div>
            <p>点击或拖拽上传文件</p>
            <p class="upload-hint">支持 .txt .docx .pdf 格式</p>
          </div>

          <div v-if="uploading" class="upload-progress">
            <el-progress :percentage="uploadProgress" :status="uploadStatus" />
          </div>

          <div v-if="uploadMessage" class="upload-message" :class="uploadSuccess ? 'success' : 'error'">
            {{ uploadMessage }}
          </div>
        </div>

        <div class="sidebar-section">
          <h3>💡 快捷问题</h3>
          <button v-for="q in quickQuestions" :key="q" @click="sendQuickQuestion(q)" class="quick-btn">
            {{ q }}
          </button>
        </div>

        <div class="sidebar-section">
          <h3>🏷️ 热门标签</h3>
          <div class="tags-container">
            <span v-for="tag in featureTags" :key="tag" @click="handleTagClick(tag)" :class="['tag-item', { 'selected': selectedCity === tag }]">
              {{ tag }}
            </span>
          </div>
        </div>

        <div class="sidebar-section">
          <h3>📝 历史对话</h3>
          <button @click="saveHistory" class="quick-btn" :disabled="messages.length === 0">
            <i class="fas fa-save"></i> 保存当前对话
          </button>
          <div v-if="savedHistories.length > 0" class="history-list">
            <div v-for="(history, idx) in savedHistories" :key="idx" class="history-item">
              <span class="history-name">{{ history.name }}</span>
              <span class="history-count">{{ history.messages.length }}条消息</span>
              <button @click="loadHistory(idx)" class="history-load-btn">
                <i class="fas fa-download"></i>
              </button>
              <button @click="deleteHistory(idx)" class="history-delete-btn">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </div>
        </div>
      </aside>

      <main class="chat-area">
        <div class="chat-history" ref="chatHistoryRef">
          <div v-for="(message, index) in messages" :key="index" :class="['message-item', message.type]">
            <div class="message-avatar">
              {{ message.type === 'user' ? '👤' : '🤖' }}
            </div>
            <div class="message-content">
              <div class="message-header">
                {{ message.type === 'user' ? '您' : '旅游助手' }}
                <span class="message-time">{{ message.time }}</span>
                <span v-if="message.type === 'bot' && message.intents?.length" class="message-intents">
                  {{ message.intents.join(' · ') }}
                </span>
              </div>
              <div class="message-body">
                <div v-if="message.type === 'bot'" class="bot-answer">
                  <template v-if="message.plan && message.plan.success">
                    <div class="travel-plan">
                      <div class="plan-header">
                        <h3>🗺️ {{ message.plan.title }}</h3>
                        <p class="plan-desc">{{ message.plan.description }}</p>
                        <div v-if="message.plan.budget || message.plan.from_city" class="plan-meta">
                          <span v-if="message.plan.from_city" class="meta-item">📍 从{{ message.plan.from_city }}出发</span>
                          <span v-if="message.plan.budget" class="meta-item">💰 预算{{ message.plan.budget }}元 ({{ message.plan.budget_level }})</span>
                          <span v-if="message.plan.season" class="meta-item">🌤️ 推荐季节：{{ message.plan.season }}</span>
                          <span v-if="message.plan.days" class="meta-item">📅 建议游玩{{ message.plan.days }}天</span>
                        </div>
                        
                        <div v-if="message.plan.budget_details" class="plan-budget-details">
                          <h4>💸 预算明细</h4>
                          <div class="budget-grid">
                            <div class="budget-item">
                              <span class="budget-label">🚄 交通费用</span>
                              <span class="budget-value">{{ message.plan.budget_details.transport }}元</span>
                            </div>
                            <div class="budget-item">
                              <span class="budget-label">🏨 住宿费用</span>
                              <span class="budget-value">{{ message.plan.budget_details.accommodation }}元</span>
                            </div>
                            <div class="budget-item">
                              <span class="budget-label">🎫 景点门票</span>
                              <span class="budget-value">{{ message.plan.budget_details.attractions }}元</span>
                            </div>
                            <div class="budget-item">
                              <span class="budget-label">🍽️ 餐饮费用</span>
                              <span class="budget-value">{{ message.plan.budget_details.food }}元</span>
                            </div>
                            <div class="budget-item total" :class="{ 'over-budget': message.plan.budget_details.is_over_budget }">
                              <span class="budget-label">📊 总计</span>
                              <span class="budget-value">{{ message.plan.budget_details.total }}元</span>
                              <span v-if="message.plan.budget_details.is_over_budget" class="budget-status over">⚠️ 超支</span>
                              <span v-else class="budget-status under">✅ 预算内</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.recommendations?.length" class="plan-recommendations">
                        <h4>📍 推荐目的地</h4>
                        <div class="recommendation-cards">
                          <div v-for="rec in message.plan.recommendations" :key="rec.city" class="rec-card">
                            <div class="rec-header">
                              <span class="rec-city">{{ rec.city }}</span>
                              <span class="rec-rating">⭐ {{ rec.rating }}</span>
                            </div>
                            <p class="rec-desc">{{ rec.description }}</p>
                            <div class="rec-info">
                              <span>💰 {{ rec.price_range }}</span>
                            </div>
                            <div class="rec-details">
                              <span>🏞️ {{ rec.best_attractions.join('、') }}</span>
                              <span>🍜 {{ rec.special_food.join('、') }}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.daily_plan?.length" class="plan-daily">
                        <h4>📅 每日行程</h4>
                        <div v-for="day in message.plan.daily_plan" :key="day.day" class="day-card">
                          <div class="day-header">
                            <span class="day-number">第 {{ day.day }} 天</span>
                            <span class="day-label">Day {{ day.day }}</span>
                          </div>
                          <div class="day-content">
                            <div class="time-block">
                              <span class="time-label">🌅 上午</span>
                              <span class="time-content">{{ day.morning }}</span>
                            </div>
                            <div class="time-block">
                              <span class="time-label">☀️ 下午</span>
                              <span class="time-content">{{ day.afternoon }}</span>
                            </div>
                            <div class="time-block">
                              <span class="time-label">🌙 晚上</span>
                              <span class="time-content">{{ day.evening }}</span>
                            </div>
                          </div>
                          <div v-if="day.attractions?.length" class="day-attractions">
                            <div class="attraction-title">🎫 景点详情</div>
                            <div v-for="attraction in day.attractions" :key="attraction.名称" class="attraction-item">
                              <div class="attraction-header">
                                <div class="attraction-name">{{ attraction.名称 }}</div>
                                <span class="attraction-tag">{{ attraction.特色 }}</span>
                              </div>
                              <div class="attraction-info">
                                <span>💰 {{ attraction.票价 }}</span>
                                <span>⏰ {{ attraction.开放时间 }}</span>
                                <span>⌛ {{ attraction.游玩时长 }}</span>
                                <span>⭐ {{ attraction.评分 }}</span>
                              </div>
                              <div v-if="attraction.介绍" class="attraction-desc">{{ attraction.介绍 }}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.hotels?.length" class="plan-hotels">
                        <h4>🏨 住宿推荐</h4>
                        <div class="hotel-cards">
                          <div v-for="hotel in message.plan.hotels" :key="hotel.名称" class="hotel-card">
                            <div class="hotel-name">{{ hotel.名称 }}</div>
                            <div class="hotel-info">
                              <span class="hotel-level">{{ hotel.档次 }}</span>
                              <span class="hotel-price">💰 {{ hotel.价格 }}</span>
                            </div>
                            <div class="hotel-location">📍 {{ hotel.位置 }}</div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.foods?.length" class="plan-foods">
                        <h4>🍽️ 美食推荐</h4>
                        <div class="food-cards">
                          <div v-for="food in message.plan.foods" :key="food.名称" class="food-card">
                            <div class="food-name">{{ food.名称 }}</div>
                            <div class="food-info">
                              <span>{{ food.特色 }}</span>
                              <span>💰 {{ food.人均 }}</span>
                            </div>
                            <div class="food-recommend">推荐：{{ food.推荐菜.join('、') }}</div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.transport?.length" class="plan-transport">
                        <h4>🚗 交通指南</h4>
                        <div class="transport-cards">
                          <div v-for="transport in message.plan.transport" :key="transport.from + '-' + transport.to" class="transport-card">
                            <div class="transport-route">{{ transport.from }} → {{ transport.to }}</div>
                            <div class="transport-options">
                              <div v-for="option in transport.options" :key="option.type" class="transport-option">
                                <span class="option-type">{{ option.type }}</span>
                                <span v-if="option.train" class="option-detail">🚂 {{ option.train }}</span>
                                <span class="option-detail">⏱️ {{ option.duration }}</span>
                                <span class="option-detail">💰 {{ option.price_range || option.price }}</span>
                                <span class="option-detail">📆 {{ option.frequency }}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div v-if="message.plan.tips?.length" class="plan-tips">
                        <h4>💡 旅行小贴士</h4>
                        <ul>
                          <li v-for="(tip, idx) in message.plan.tips" :key="idx">{{ tip }}</li>
                        </ul>
                      </div>
                    </div>
                  </template>
                  
                  <template v-else>
                    <div v-for="(result, idx) in message.results" :key="idx" :class="['result-item', result.type]">
                      <div v-if="result.title" class="result-title">{{ result.title }}</div>
                      <div class="result-content">{{ result.content }}</div>
                      <div v-if="result.metadata" class="result-meta">
                        <span v-for="(value, key) in result.metadata" :key="key">{{ key }}: {{ value }}</span>
                      </div>
                    </div>
                    <div v-if="!message.results || message.results.length === 0" class="no-results">
                      未找到相关信息，请尝试其他问题
                    </div>
                  </template>
                </div>
                <div v-else>{{ message.content }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="chat-input">
          <el-input 
            v-model="inputMessage" 
            type="textarea"
            :rows="4"
            placeholder="输入您的问题，例如：我在北京，想去三亚旅游，预算2000元，请帮我制定一份详细的旅游计划，包含交通、住宿、景点和美食推荐。"
            class="message-input"
            @keydown.enter.exact.prevent="sendMessage"
          />
          <el-button type="primary" @click="sendMessage" :loading="sending">发送</el-button>
        </div>
      </main>

      <aside class="right-panel">
        <div class="panel-header">
          <h3>🖼️ 旅行相册</h3>
          <button class="album-toggle-btn" @click="toggleAlbumPanel" :class="{ expanded: showAlbumPanel }">
            <i class="fas fa-camera-retro"></i> {{ showAlbumPanel ? '收起' : '展开' }}
          </button>
        </div>
        
        <div v-if="showAlbumPanel" class="panel-content">
          <div class="album-tabs">
            <button 
              v-for="tab in tabs" 
              :key="tab.id" 
              :class="['tab-btn', { active: activeTab === tab.id }]"
              @click="activeTab = tab.id"
            >
              <i :class="tab.icon"></i> {{ tab.name }}
            </button>
          </div>
          
          <div class="tab-content">
            <Album v-show="activeTab === 'album'" :media="mediaList" @update="fetchMediaList" />
            <Timeline v-show="activeTab === 'timeline'" :media="mediaList" />
            <VlogMaker v-show="activeTab === 'vlog'" :media="mediaList" :music-list="musicList" @update:music-list="(val) => musicList = val" />
            <KnowledgeExplorer v-show="activeTab === 'knowledge'" />
          </div>
        </div>
      </aside>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { tourismApi, type ChatResult, type TravelPlanResponse, type ImageInfo, type MediaItem, type MusicItem } from '@/api/tourismApi'
import Album from '@/components/Album.vue'
import Timeline from '@/components/Timeline.vue'
import VlogMaker from '@/components/VlogMaker.vue'
import KnowledgeExplorer from '@/components/KnowledgeExplorer.vue'

const fileInputRef = ref<HTMLInputElement | null>(null)
const imageInputRef = ref<HTMLInputElement | null>(null)
const chatHistoryRef = ref<HTMLElement | null>(null)

interface ChatMessage {
  type: 'user' | 'bot'
  content?: string
  results?: ChatResult[]
  plan?: TravelPlanResponse
  intents?: string[]
  time: string
}

const messages = ref<ChatMessage[]>([])

interface SavedHistory {
  name: string;
  messages: ChatMessage[];
  savedAt: string;
}

const savedHistories = ref<SavedHistory[]>([])

const loadSavedHistories = () => {
  const saved = localStorage.getItem('tourism_chat_histories');
  if (saved) {
    savedHistories.value = JSON.parse(saved);
  }
}

const saveHistory = () => {
  if (messages.value.length === 0) return;
  
  const firstUserMessage = messages.value.find(m => m.type === 'user');
  const name = firstUserMessage ? firstUserMessage.content.slice(0, 20) + (firstUserMessage.content.length > 20 ? '...' : '') : `对话 ${savedHistories.value.length + 1}`;
  
  const history: SavedHistory = {
    name,
    messages: JSON.parse(JSON.stringify(messages.value)),
    savedAt: new Date().toLocaleString('zh-CN')
  };
  
  savedHistories.value.push(history);
  localStorage.setItem('tourism_chat_histories', JSON.stringify(savedHistories.value));
  ElMessage.success('对话保存成功');
}

const loadHistory = (idx: number) => {
  const history = savedHistories.value[idx];
  if (history) {
    messages.value = JSON.parse(JSON.stringify(history.messages));
    ElMessage.success('对话加载成功');
  }
}

const deleteHistory = (idx: number) => {
  savedHistories.value.splice(idx, 1);
  localStorage.setItem('tourism_chat_histories', JSON.stringify(savedHistories.value));
  ElMessage.success('对话删除成功');
}

const inputMessage = ref('')
const sending = ref(false)
const uploading = ref(false)
const uploadProgress = ref(0)
const uploadStatus = ref<'success' | 'exception' | 'warning' | ''>('')
const uploadMessage = ref('')
const uploadSuccess = ref(false)
const documentCount = ref(0)

const images = ref<ImageInfo[]>([])
const selectedImage = ref<ImageInfo | null>(null)
const imageInfo = ref({
  travel_date: '',
  location_name: '',
  ai_description: ''
})

const showAlbumPanel = ref(true)
const showAlbumModal = ref(false)

const tabs = [
  { id: 'album', name: '相册', icon: 'fas fa-images' },
  { id: 'timeline', name: '时间线', icon: 'fas fa-timeline' },
  { id: 'vlog', name: '制作Vlog', icon: 'fas fa-video' },
  { id: 'knowledge', name: '知识库', icon: 'fas fa-book' }
]

const activeTab = ref('album')
const mediaList = ref<MediaItem[]>([])
const musicList = ref<MusicItem[]>([])

const quickQuestions = [
  '北京有什么好玩的',
  '成都美食推荐',
  '寒假去哪里旅游',
  '西安旅游避坑指南',
  '杭州西湖门票价格',
  '三亚最佳旅游时间'
]

const featureTags = [
  '北京', '上海', '杭州', '成都', '西安',
  '美食', '门票', '避坑', '攻略', '春季', '冬季'
]

const cityTags = ['北京', '上海', '杭州', '成都', '西安', '重庆', '三亚', '哈尔滨', '青岛', '苏州', '南京', '武汉', '广州', '深圳', '厦门', '丽江', '桂林', '昆明', '长沙', '天津']
const selectedCity = ref('')

const handleTagClick = (tag: string) => {
  if (cityTags.includes(tag)) {
    selectedCity.value = tag
    inputMessage.value = tag
  } else {
    if (selectedCity.value) {
      inputMessage.value = `${selectedCity.value}${tag}`
      sendMessage()
    } else {
      inputMessage.value = tag
      sendMessage()
    }
  }
}

const formatTime = () => {
  const now = new Date()
  return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
}

const scrollToBottom = async () => {
  await nextTick()
  if (chatHistoryRef.value) {
    chatHistoryRef.value.scrollTop = chatHistoryRef.value.scrollHeight
  }
}

const sendMessage = async () => {
  const query = inputMessage.value.trim()
  if (!query) return

  messages.value.push({
    type: 'user',
    content: query,
    time: formatTime()
  })
  inputMessage.value = ''
  sending.value = true

  try {
    const cityKeywords = ['北京', '上海', '杭州', '成都', '西安', '重庆', '三亚', '哈尔滨', '青岛', '苏州', '南京', '武汉', '广州', '深圳', '厦门', '丽江', '桂林', '昆明', '长沙', '天津']
    const containsCity = cityKeywords.some(city => query.includes(city))
    
    const planKeywords = ['行程', '计划', '路线', '攻略', '旅游方案', '安排']
    const isPlanQuery = planKeywords.some(keyword => query.includes(keyword))
    
    const specificInfoKeywords = ['门票', '价格', '多少钱', '避坑', '注意', '美食', '吃', '餐厅', '交通', '怎么去', '酒店', '住宿', '天气', '季节', '什么时候', '最佳']
    const isSpecificInfoQuery = specificInfoKeywords.some(keyword => query.includes(keyword))
    
    if (isPlanQuery) {
      const planResponse = await tourismApi.plan(query)
      
      if (planResponse.success) {
        messages.value.push({
          type: 'bot',
          plan: planResponse,
          intents: ['行程计划'],
          time: formatTime()
        })
      } else {
        const chatResponse = await tourismApi.chat(query)
        messages.value.push({
          type: 'bot',
          results: chatResponse.results,
          intents: chatResponse.intents,
          time: formatTime()
        })
      }
    } else {
      const response = await tourismApi.chat(query)
      messages.value.push({
        type: 'bot',
        results: response.results,
        intents: response.intents,
        time: formatTime()
      })
    }
  } catch (error) {
    ElMessage.error('发送失败，请稍后重试')
    messages.value.push({
      type: 'bot',
      results: [],
      intents: [],
      time: formatTime()
    })
  } finally {
    sending.value = false
    scrollToBottom()
  }
}

const sendQuickQuestion = (question: string) => {
  inputMessage.value = question
  sendMessage()
}

const triggerFileInput = () => {
  fileInputRef.value?.click()
}

const handleFileSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  const files = target.files
  if (files && files.length > 0) {
    uploadFiles(Array.from(files))
  }
}

const handleDrop = (event: DragEvent) => {
  const files = event.dataTransfer?.files
  if (files && files.length > 0) {
    uploadFiles(Array.from(files))
  }
}

const uploadFiles = async (files: File[]) => {
  uploading.value = true
  uploadProgress.value = 0
  uploadMessage.value = ''

  try {
    for (let i = 0; i < files.length; i++) {
      uploadProgress.value = Math.round(((i + 1) / files.length) * 50)
      
      const response = await tourismApi.upload(files[i])
      
      if (response.success) {
        uploadProgress.value = Math.round(((i + 1) / files.length) * 100)
        uploadSuccess.value = true
        uploadMessage.value = `${files[i].name} 上传成功，入库 ${response.total_chunks} 条`
      } else {
        throw new Error(response.message)
      }
    }
    
    uploadStatus.value = 'success'
    await fetchStats()
  } catch (error) {
    uploadStatus.value = 'exception'
    uploadSuccess.value = false
    uploadMessage.value = `上传失败: ${error instanceof Error ? error.message : '未知错误'}`
  } finally {
    uploading.value = false
    if (fileInputRef.value) {
      fileInputRef.value.value = ''
    }
  }
}

const fetchStats = async () => {
  try {
    const response = await tourismApi.stats()
    documentCount.value = response.document_count
  } catch {
    documentCount.value = 0
  }
}

const checkHealth = async () => {
  try {
    await tourismApi.health()
  } catch {
    ElMessage.warning('后端服务未连接，请启动后端服务')
  }
}

const triggerImageInput = () => {
  imageInputRef.value?.click()
}

const handleImageSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  const files = target.files
  if (files && files.length > 0) {
    uploadImages(Array.from(files))
  }
}

const handleImageDrop = (event: DragEvent) => {
  const files = event.dataTransfer?.files
  if (files && files.length > 0) {
    uploadImages(Array.from(files))
  }
}

const uploadImages = async (files: File[]) => {
  try {
    for (const file of files) {
      const response = await tourismApi.uploadMedia(file)
      if (response) {
        ElMessage.success(`${file.name} 上传成功`)
      }
    }
    await fetchImages()
  } catch (error) {
    ElMessage.error('图片上传失败')
  } finally {
    if (imageInputRef.value) {
      imageInputRef.value.value = ''
    }
  }
}

const fetchImages = async () => {
  try {
    const response = await tourismApi.getMediaList()
    images.value = response.map(img => ({
      id: img.id,
      filename: img.filename,
      url: `/uploads/${img.filename}`,
      upload_time: img.upload_time
    }))
  } catch {
    images.value = []
  }
}

const deleteImage = async (imageId: string) => {
  try {
    await tourismApi.deleteMedia(imageId)
    images.value = images.value.filter(img => img.id !== imageId)
    if (selectedImage.value?.id === imageId) {
      selectedImage.value = null
      imageInfo.value = { travel_date: '', location_name: '', ai_description: '' }
    }
    ElMessage.success('图片删除成功')
  } catch {
    ElMessage.error('删除失败')
  }
}

const selectImage = (image: ImageInfo) => {
  selectedImage.value = image
  imageInfo.value = {
    travel_date: '',
    location_name: '',
    ai_description: ''
  }
}

const toggleAlbumPanel = () => {
  showAlbumPanel.value = !showAlbumPanel.value
}

const openTimeline = () => {
  showAlbumModal.value = true
}

const generateAiCopy = async () => {
  if (!selectedImage.value) return
  
  try {
    const response = await tourismApi.generateDescription(selectedImage.value.id, {
      location_name: imageInfo.value.location_name,
      travel_date: imageInfo.value.travel_date
    })
    imageInfo.value.ai_description = response.description
    ElMessage.success('AI文案生成成功')
  } catch (error) {
    ElMessage.error('AI文案生成失败，使用默认文案')
    imageInfo.value.ai_description = '在旅途中的美好时光，留下了珍贵的回忆。画面中的每一个细节都诉说着旅途的故事，这是一段值得珍藏的旅行记忆。'
  }
}

const openVlogCreator = () => {
  showAlbumModal.value = true
}

const saveImageInfo = async () => {
  if (!selectedImage.value) return
  
  try {
    await tourismApi.updateMedia(selectedImage.value.id, {
      travel_date: imageInfo.value.travel_date || null,
      location_name: imageInfo.value.location_name || null,
      ai_description: imageInfo.value.ai_description || null
    })
    ElMessage.success('信息保存成功')
  } catch {
    ElMessage.error('保存失败')
  }
}

const fetchMediaList = async () => {
  try {
    mediaList.value = await tourismApi.getMediaList()
  } catch {
    mediaList.value = []
  }
}

const fetchMusicList = async () => {
  try {
    musicList.value = await tourismApi.getMusicList()
  } catch {
    musicList.value = []
  }
}

onMounted(() => {
  fetchStats()
  checkHealth()
  fetchImages()
  fetchMediaList()
  fetchMusicList()
  loadSavedHistories()
})
</script>

<style scoped>
.tourism-assistant {
  min-height: 100vh;
  background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
  display: flex;
  flex-direction: column;
}

.header {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  padding: 16px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.header-content h1 {
  font-size: 24px;
  color: #0369a1;
  margin: 0;
}

.header-content p {
  font-size: 14px;
  color: #64748b;
  margin: 4px 0 0;
}

.header-stats {
  font-size: 14px;
  color: #0369a1;
}

.stats-item {
  background: #e0f2fe;
  padding: 8px 16px;
  border-radius: 20px;
}

.main-content {
  display: flex;
  padding: 24px;
  gap: 24px;
  height: calc(100vh - 80px);
  overflow: hidden;
}

.sidebar {
  width: 300px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 20px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow-y: auto;
}

.sidebar-section {
  margin-bottom: 24px;
}

.sidebar-section h3 {
  font-size: 16px;
  color: #1e293b;
  margin: 0 0 12px;
}

.upload-area {
  border: 2px dashed #93c5fd;
  border-radius: 12px;
  padding: 32px 16px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  background: #f0f9ff;
}

.upload-area:hover {
  border-color: #3b82f6;
  background: #eff6ff;
}

.file-input {
  display: none;
}

.upload-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.upload-area p {
  margin: 0;
  font-size: 14px;
  color: #475569;
}

.upload-hint {
  font-size: 12px;
  color: #94a3b8;
  margin-top: 8px !important;
}

.upload-progress {
  margin-top: 16px;
}

.upload-message {
  margin-top: 12px;
  padding: 12px;
  border-radius: 8px;
  font-size: 13px;
}

.upload-message.success {
  background: #dcfce7;
  color: #16a34a;
}

.upload-message.error {
  background: #fee2e2;
  color: #dc2626;
}

.quick-btn {
  display: block;
  width: 100%;
  padding: 10px 14px;
  margin-bottom: 8px;
  text-align: left;
  background: #f1f5f9;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  color: #475569;
  cursor: pointer;
  transition: all 0.2s ease;
}

.quick-btn:hover {
  background: #e0f2fe;
  color: #0369a1;
}

.history-list {
  margin-top: 10px;
  max-height: 200px;
  overflow-y: auto;
}

.history-item {
  display: flex;
  align-items: center;
  padding: 8px 10px;
  margin-bottom: 5px;
  background: #f8fafc;
  border-radius: 6px;
  font-size: 0.8rem;
}

.history-name {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: #334155;
}

.history-count {
  color: #94a3b8;
  font-size: 0.7rem;
  margin-right: 8px;
}

.history-load-btn,
.history-delete-btn {
  width: 24px;
  height: 24px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  margin-left: 4px;
}

.history-load-btn {
  background: #dbeafe;
  color: #3b82f6;
}

.history-load-btn:hover {
  background: #bfdbfe;
}

.history-delete-btn {
  background: #fee2e2;
  color: #ef4444;
}

.history-delete-btn:hover {
  background: #fecaca;
}

.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tag-item {
  padding: 6px 12px;
  background: #e0f2fe;
  border-radius: 16px;
  font-size: 12px;
  color: #0369a1;
  cursor: pointer;
  transition: all 0.2s ease;
}

.tag-item:hover {
  background: #3b82f6;
  color: white;
}

.tag-item.selected {
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  color: white;
  box-shadow: 0 2px 8px rgba(0, 188, 212, 0.4);
}

.chat-area {
  flex: 1;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  overflow: hidden;
}

.chat-history {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
}

.message-item {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.message-item.user {
  flex-direction: row-reverse;
}

.message-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #e0f2fe;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}

.message-item.user .message-avatar {
  background: #bfdbfe;
}

.message-content {
  max-width: 70%;
}

.message-item.user .message-content {
  text-align: right;
}

.message-header {
  font-size: 12px;
  color: #64748b;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.message-item.user .message-header {
  justify-content: flex-end;
}

.message-time {
  font-size: 11px;
  color: #94a3b8;
}

.message-intents {
  font-size: 11px;
  color: #3b82f6;
  background: #e0f2fe;
  padding: 2px 8px;
  border-radius: 10px;
  margin-left: 8px;
}

.message-body {
  background: #f8fafc;
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.6;
  color: #1e293b;
}

.message-item.user .message-body {
  background: #3b82f6;
  color: white;
}

.bot-answer {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.result-item {
  padding: 12px;
  border-radius: 8px;
  margin-bottom: 12px;
}

.result-item.card {
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border-left: 3px solid #3b82f6;
}

.result-item.knowledge {
  background: #f8fafc;
  border-left: 3px solid #10b981;
}

.result-item.text {
  background: #fef3c7;
  border-left: 3px solid #f59e0b;
}

.result-title {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.result-content {
  font-size: 13px;
  color: #334155;
  line-height: 1.7;
  white-space: pre-wrap;
}

.result-meta {
  margin-top: 8px;
  font-size: 11px;
  color: #94a3b8;
  display: flex;
  gap: 12px;
}

.no-results {
  color: #94a3b8;
  font-size: 14px;
  text-align: center;
}

.chat-input {
  padding: 16px 24px;
  border-top: 1px solid #e2e8f0;
  display: flex;
  gap: 12px;
}

.message-input {
  flex: 1;
}

.message-input :deep(.el-input__wrapper) {
  border-radius: 12px;
}

.message-input :deep(.el-input__inner) {
  padding: 12px 16px;
}

.chat-input button {
  border-radius: 12px;
  padding: 0 24px;
}

.right-panel {
  width: 320px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 20px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  overflow-y: auto;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.panel-header h3 {
  font-size: 16px;
  color: #1e293b;
  margin: 0;
}

.album-toggle-btn {
  padding: 6px 12px;
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  border: none;
  border-radius: 6px;
  font-size: 12px;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s ease;
}

.album-toggle-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 188, 212, 0.4);
}

.panel-content {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.album-tabs {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.tab-btn {
  padding: 6px 10px;
  border: none;
  border-radius: 6px;
  font-size: 0.8rem;
  color: #64748b;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
  background: #f1f5f9;
  transition: all 0.2s ease;
}

.tab-btn.active {
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  color: white;
}

.tab-btn:hover:not(.active) {
  background: #e0f7fa;
}

.tab-content {
  flex: 1;
  overflow-y: auto;
  max-height: calc(100vh - 220px);
}

.image-upload-section h4 {
  font-size: 14px;
  color: #1e293b;
  margin: 0 0 12px;
}

.image-upload-area {
  border: 2px dashed #93c5fd;
  border-radius: 12px;
  padding: 20px 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  background: #f0f9ff;
}

.image-upload-area:hover {
  border-color: #3b82f6;
  background: #eff6ff;
}

.image-input {
  display: none;
}

.image-upload-icon {
  font-size: 36px;
  margin-bottom: 8px;
}

.image-upload-area p {
  margin: 0;
  font-size: 13px;
  color: #475569;
}

.image-upload-hint {
  font-size: 11px;
  color: #94a3b8;
  margin-top: 6px !important;
}

.image-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-top: 12px;
}

.image-item {
  position: relative;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  aspect-ratio: 1;
  border: 2px solid transparent;
  transition: all 0.2s ease;
}

.image-item:hover {
  border-color: #3b82f6;
}

.image-thumb {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.delete-image-btn {
  position: absolute;
  bottom: 4px;
  right: 4px;
  width: 24px;
  height: 24px;
  background: rgba(239, 68, 68, 0.9);
  border: none;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 12px;
  opacity: 0;
  transition: opacity 0.2s ease;
}

.image-item:hover .delete-image-btn {
  opacity: 1;
}

.album-features h4 {
  font-size: 14px;
  color: #1e293b;
  margin: 0 0 12px;
}

.feature-buttons {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.feature-btn {
  padding: 10px 14px;
  border: none;
  border-radius: 8px;
  font-size: 13px;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s ease;
}

.feature-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.timeline-btn {
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
}

.timeline-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
}

.copy-btn {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
}

.copy-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
}

.vlog-btn {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
}

.vlog-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(245, 158, 11, 0.4);
}

.selected-image-info h4 {
  font-size: 14px;
  color: #1e293b;
  margin: 0 0 12px;
}

.selected-image-preview {
  width: 100%;
  max-height: 150px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 12px;
}

.info-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.form-row {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.form-row label {
  font-size: 12px;
  color: #64748b;
}

.form-row input,
.form-row textarea {
  padding: 8px;
  border: 1px solid #e2e8f0;
  border-radius: 6px;
  font-size: 13px;
}

.form-row textarea {
  resize: vertical;
  min-height: 60px;
}

.save-btn {
  padding: 8px 14px;
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  border: none;
  border-radius: 6px;
  font-size: 13px;
  color: white;
  cursor: pointer;
  margin-top: 8px;
}

.save-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 188, 212, 0.4);
}

.travel-plan {
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border-radius: 12px;
  padding: 20px;
}

.plan-header h3 {
  font-size: 18px;
  color: #0369a1;
  margin: 0 0 8px;
}

.plan-desc {
  font-size: 13px;
  color: #64748b;
  margin: 0;
}

.plan-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-top: 12px;
}

.meta-item {
  font-size: 12px;
  color: #64748b;
  background: white;
  padding: 4px 10px;
  border-radius: 12px;
  border: 1px solid #e2e8f0;
}

.plan-recommendations,
.plan-daily,
.plan-hotels,
.plan-foods,
.plan-tips {
  margin-top: 20px;
}

.plan-recommendations h4,
.plan-daily h4,
.plan-hotels h4,
.plan-foods h4,
.plan-tips h4 {
  font-size: 15px;
  color: #1e293b;
  margin: 0 0 12px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.recommendation-cards,
.hotel-cards,
.food-cards {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.rec-card,
.hotel-card,
.food-card {
  background: white;
  border-radius: 8px;
  padding: 14px;
  border-left: 3px solid #3b82f6;
}

.rec-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}

.rec-city {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
}

.rec-rating {
  font-size: 12px;
  color: #f59e0b;
}

.rec-desc {
  font-size: 12px;
  color: #64748b;
  margin: 0 0 8px;
}

.rec-info {
  font-size: 12px;
  color: #3b82f6;
  margin-bottom: 8px;
}

.rec-details {
  font-size: 12px;
  color: #64748b;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.day-card {
  background: white;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 12px;
}

.day-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
  padding-bottom: 8px;
  border-bottom: 1px solid #e2e8f0;
}

.day-number {
  font-size: 15px;
  font-weight: 600;
  color: #0369a1;
}

.day-label {
  font-size: 12px;
  color: #94a3b8;
}

.day-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.time-block {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.time-label {
  font-size: 13px;
  color: #3b82f6;
  font-weight: 500;
  width: 50px;
  flex-shrink: 0;
}

.time-content {
  font-size: 13px;
  color: #334155;
}

.day-attractions {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px dashed #cbd5e1;
}

.attraction-title {
  font-size: 12px;
  color: #64748b;
  margin-bottom: 8px;
}

.attraction-item {
  background: #f8fafc;
  border-radius: 6px;
  padding: 10px;
  margin-bottom: 8px;
}

.attraction-item:last-child {
  margin-bottom: 0;
}

.attraction-name {
  font-size: 13px;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 6px;
}

.attraction-info {
  font-size: 11px;
  color: #64748b;
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.hotel-name,
.food-name {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 6px;
}

.hotel-info,
.food-info {
  font-size: 12px;
  color: #64748b;
  display: flex;
  gap: 12px;
  margin-bottom: 6px;
}

.hotel-level {
  background: #dbeafe;
  color: #1d4ed8;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
}

.hotel-location {
  font-size: 12px;
  color: #64748b;
}

.food-recommend {
  font-size: 12px;
  color: #16a34a;
}

.plan-tips ul {
  margin: 0;
  padding-left: 20px;
}

.plan-tips li {
  font-size: 13px;
  color: #64748b;
  margin-bottom: 6px;
}

.plan-tips li:last-child {
  margin-bottom: 0;
}

.plan-transport {
  margin-top: 20px;
}

.plan-transport h4 {
  font-size: 15px;
  color: #1e293b;
  margin: 0 0 12px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.transport-cards {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.transport-card {
  background: white;
  border-radius: 8px;
  padding: 14px;
  border-left: 3px solid #f59e0b;
}

.transport-route {
  font-size: 14px;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 10px;
}

.transport-options {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.transport-option {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  font-size: 12px;
}

.option-type {
  background: #fef3c7;
  color: #d97706;
  padding: 2px 8px;
  border-radius: 4px;
  font-weight: 500;
}

.option-detail {
  color: #64748b;
}

.plan-budget-details {
  margin-top: 16px;
  padding: 16px;
  background: white;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
}

.plan-budget-details h4 {
  font-size: 14px;
  color: #1e293b;
  margin: 0 0 12px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.budget-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 10px;
}

.budget-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background: #f8fafc;
  border-radius: 6px;
}

.budget-item.total {
  background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
  grid-column: 1 / -1;
}

.budget-label {
  font-size: 12px;
  color: #64748b;
}

.budget-value {
  font-size: 13px;
  font-weight: 600;
  color: #1e293b;
}

.budget-item.total .budget-value {
  color: #0369a1;
}

.attraction-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}

.attraction-tag {
  font-size: 11px;
  color: #16a34a;
  background: #dcfce7;
  padding: 2px 8px;
  border-radius: 4px;
}

.attraction-desc {
  font-size: 12px;
  color: #64748b;
  line-height: 1.6;
  margin-top: 8px;
  padding-top: 8px;
  border-top: 1px dashed #e2e8f0;
}

.message-input :deep(.el-textarea__inner) {
  min-height: 80px;
  padding: 12px 16px;
}

.budget-item.total.over-budget {
  background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
}

.budget-item.total.over-budget .budget-value {
  color: #dc2626;
}

.budget-status {
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
}

.budget-status.over {
  background: #fef2f2;
  color: #dc2626;
}

.budget-status.under {
  background: #ecfdf5;
  color: #059669;
}
</style>