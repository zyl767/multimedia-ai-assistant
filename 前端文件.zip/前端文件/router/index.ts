import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'TourismAssistant',
    component: () => import('../views/TourismAssistant.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router