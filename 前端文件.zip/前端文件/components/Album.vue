<template>
  <div class="album">
    <div class="upload-section">
      <div 
        class="upload-area" 
        @click="$refs.fileInput.click()"
        @dragover.prevent="isDragOver = true"
        @dragleave.prevent="isDragOver = false"
        @drop.prevent="handleDrop"
        :class="{ dragover: isDragOver }"
      >
        <i class="fas fa-cloud-upload-alt"></i>
        <p>点击或拖拽上传照片/视频</p>
        <p class="upload-hint">支持 JPG、PNG、GIF、MP4 格式</p>
        <input 
          type="file" 
          ref="fileInput" 
          accept="image/*,video/*" 
          multiple
          @change="handleFileChange"
          style="display: none;"
        />
      </div>
      <div v-if="uploading" class="upload-progress">
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: uploadProgress + '%' }"></div>
        </div>
        <span>上传中... {{ uploadProgress }}%</span>
      </div>
    </div>

    <div class="album-grid" v-if="media.length > 0">
      <div v-for="item in media" :key="item.id" class="album-card">
        <div class="card-thumbnail" @click="openEdit(item)">
          <img v-if="item.media_type === 'image'" :src="getMediaUrl(item.filename)" :alt="item.original_name" />
          <video v-else :src="getMediaUrl(item.filename)"></video>
          <div class="card-overlay">
            <i class="fas fa-edit"></i> 编辑
          </div>
        </div>
        <div class="card-info">
          <p class="card-name">{{ item.original_name }}</p>
          <p class="card-meta">
            <span v-if="item.location_name"><i class="fas fa-map-marker-alt"></i> {{ item.location_name }}</span>
            <span v-if="item.travel_date"><i class="fas fa-calendar"></i> {{ item.travel_date }}</span>
          </p>
          <button class="delete-btn" @click.stop="deleteMedia(item.id)">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    </div>
    <div v-else class="empty">
      <i class="fas fa-images"></i>
      <p>相册为空，请上传照片</p>
    </div>

    <div v-if="editing" class="modal-overlay" @click.self="closeEdit">
      <div class="modal-content">
        <div class="modal-header">
          <h3>编辑照片信息</h3>
          <button class="close-btn" @click="closeEdit"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
          <div class="preview">
            <img v-if="editing.media_type === 'image'" :src="getMediaUrl(editing.filename)" />
            <video v-else :src="getMediaUrl(editing.filename)" controls></video>
          </div>
          
          <div class="form-group">
            <label>旅行日期</label>
            <input type="date" v-model="editForm.travel_date" />
          </div>
          
          <div class="form-group">
            <label>地点名称</label>
            <input type="text" v-model="editForm.location_name" placeholder="如：北京天安门" />
          </div>
          
          <div class="form-group">
            <label>AI文案</label>
            <textarea v-model="editForm.ai_description" rows="4" placeholder="点击生成AI文案"></textarea>
            <button class="btn-ai" @click="generateDesc" :disabled="generating">
              <i class="fas fa-magic"></i> {{ generating ? '生成中...' : '生成AI文案' }}
            </button>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn-cancel" @click="closeEdit">取消</button>
          <button class="btn-save" @click="saveEdit">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { tourismApi } from '@/api/tourismApi';

const props = defineProps({
  media: { type: Array, default: () => [] }
});
const emit = defineEmits(['update']);

const fileInput = ref(null);
const isDragOver = ref(false);
const uploading = ref(false);
const uploadProgress = ref(0);
const editing = ref(null);
const editForm = ref({});
const generating = ref(false);

const getMediaUrl = (filename) => `/uploads/${filename}`;

const handleFileChange = (e) => {
  if (e.target.files.length > 0) uploadFiles(Array.from(e.target.files));
};

const handleDrop = (e) => {
  isDragOver.value = false;
  if (e.dataTransfer.files.length > 0) uploadFiles(Array.from(e.dataTransfer.files));
};

const uploadFiles = async (files) => {
  uploading.value = true;
  uploadProgress.value = 0;
  
  for (let i = 0; i < files.length; i++) {
    const formData = new FormData();
    formData.append('file', files[i]);
    
    try {
      await tourismApi.uploadMedia(files[i]);
    } catch (err) {
      console.error('上传异常:', err);
    }
    
    uploadProgress.value = Math.round(((i + 1) / files.length) * 100);
  }
  
  uploading.value = false;
  emit('update');
};

const openEdit = (item) => {
  editing.value = item;
  editForm.value = {
    travel_date: item.travel_date || '',
    location_name: item.location_name || '',
    ai_description: item.ai_description || ''
  };
};

const closeEdit = () => {
  editing.value = null;
};

const generateDesc = async () => {
  if (!editing.value) return;
  generating.value = true;
  
  try {
    const response = await tourismApi.generateDescription(editing.value.id, {
      location_name: editForm.value.location_name || '旅行时光',
      travel_date: editForm.value.travel_date || new Date().toISOString().split('T')[0],
      additional_context: ''
    });
    editForm.value.ai_description = response.description;
    ElMessage.success('AI文案生成成功');
  } catch (err) {
    console.error('生成文案失败:', err);
    editForm.value.ai_description = '在旅途中的美好时光，留下了珍贵的回忆。';
    ElMessage.error('生成失败，使用默认文案');
  } finally {
    generating.value = false;
  }
};

const saveEdit = async () => {
  if (!editing.value) return;
  
  try {
    await tourismApi.updateMedia(editing.value.id, {
      travel_date: editForm.value.travel_date || null,
      location_name: editForm.value.location_name || null,
      ai_description: editForm.value.ai_description || null
    });
    closeEdit();
    emit('update');
    ElMessage.success('保存成功');
  } catch (err) {
    console.error('保存失败:', err);
    ElMessage.error('保存失败');
  }
};

const deleteMedia = async (id) => {
  if (!confirm('确定要删除这张照片吗？')) return;
  
  try {
    await tourismApi.deleteMedia(id);
    emit('update');
    ElMessage.success('删除成功');
  } catch (err) {
    console.error('删除失败:', err);
    ElMessage.error('删除失败');
  }
};
</script>

<style scoped>
.album {
  max-width: 100%;
}

.upload-section {
  margin-bottom: 20px;
}

.upload-area {
  border: 2px dashed #00bcd4;
  border-radius: 10px;
  padding: 25px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  background: rgba(255, 255, 255, 0.5);
}

.upload-area:hover, .upload-area.dragover {
  border-color: #0097a7;
  background: rgba(255, 255, 255, 0.8);
}

.upload-area i {
  font-size: 2rem;
  color: #00bcd4;
  margin-bottom: 10px;
}

.upload-area p {
  color: #006064;
  font-size: 0.9rem;
  margin-bottom: 4px;
}

.upload-hint {
  font-size: 0.75rem !important;
  color: #00838f !important;
}

.upload-progress {
  margin-top: 10px;
}

.progress-bar {
  height: 6px;
  background: #e0f7fa;
  border-radius: 3px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  transition: width 0.3s ease;
}

.upload-progress span {
  display: block;
  text-align: center;
  margin-top: 4px;
  color: #006064;
  font-size: 0.8rem;
}

.album-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.album-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
  transition: transform 0.2s ease;
}

.album-card:hover {
  transform: translateY(-2px);
}

.card-thumbnail {
  position: relative;
  width: 100%;
  height: 100px;
  overflow: hidden;
  cursor: pointer;
}

.card-thumbnail img,
.card-thumbnail video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.card-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 0.8rem;
  opacity: 0;
  transition: opacity 0.3s ease;
}

.card-thumbnail:hover .card-overlay {
  opacity: 1;
}

.card-info {
  padding: 8px;
  position: relative;
}

.card-name {
  font-size: 0.75rem;
  color: #006064;
  margin-bottom: 3px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-meta {
  font-size: 0.7rem;
  color: #607d8b;
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.card-meta span {
  display: flex;
  align-items: center;
  gap: 3px;
}

.delete-btn {
  position: absolute;
  top: 8px;
  right: 8px;
  background: rgba(244, 67, 54, 0.1);
  color: #f44336;
  border: none;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.65rem;
}

.delete-btn:hover {
  background: #f44336;
  color: white;
}

.empty {
  text-align: center;
  padding: 40px 10px;
  color: #808080;
}

.empty i {
  font-size: 2rem;
  color: #b2ebf2;
  margin-bottom: 10px;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 450px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
  border-bottom: 1px solid #e0f7fa;
}

.modal-header h3 {
  color: #006064;
  font-size: 1rem;
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.1rem;
  color: #808080;
  cursor: pointer;
}

.modal-body {
  padding: 16px;
}

.preview {
  margin-bottom: 16px;
  text-align: center;
}

.preview img,
.preview video {
  max-width: 100%;
  max-height: 180px;
  border-radius: 8px;
}

.form-group {
  margin-bottom: 14px;
}

.form-group label {
  display: block;
  margin-bottom: 4px;
  color: #006064;
  font-weight: 500;
  font-size: 0.85rem;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 8px;
  border: 1px solid #b2ebf2;
  border-radius: 6px;
  font-size: 0.85rem;
  font-family: inherit;
}

.btn-ai {
  margin-top: 8px;
  padding: 6px 12px;
  border: none;
  border-radius: 15px;
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  color: white;
  cursor: pointer;
  font-size: 0.8rem;
}

.btn-ai:disabled {
  opacity: 0.5;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 16px;
  border-top: 1px solid #e0f7fa;
}

.btn-cancel {
  padding: 8px 16px;
  border: none;
  border-radius: 15px;
  background: #e0f7fa;
  color: #006064;
  cursor: pointer;
  font-size: 0.85rem;
}

.btn-save {
  padding: 8px 16px;
  border: none;
  border-radius: 15px;
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  color: white;
  cursor: pointer;
  font-size: 0.85rem;
}
</style>