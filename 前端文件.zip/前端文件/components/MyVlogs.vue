<template>
  <div class="my-vlogs">
    <div v-if="vlogs.length === 0" class="empty">
      <i class="fas fa-film"></i>
      <p>还没有Vlog</p>
      <p class="hint">请到"制作Vlog"页面创建</p>
    </div>

    <div v-else class="vlog-list">
      <div v-for="vlog in vlogs" :key="vlog.id" class="vlog-card">
        <div class="card-thumb" @click="preview(vlog)">
          <video v-if="vlog.video_path" :src="getVideoUrl(vlog.video_path)" :poster="getFirstMediaThumb(vlog)"></video>
          <div v-else class="thumb-placeholder">
            <i class="fas fa-video"></i>
          </div>
          <div class="play-overlay">
            <i class="fas fa-play-circle"></i>
          </div>
        </div>
        <div class="card-body">
          <h3>{{ vlog.title }}</h3>
          <p class="meta">
            <span><i class="fas fa-images"></i> {{ vlog.media_count }}个素材</span>
            <span><i class="fas fa-calendar"></i> {{ formatDate(vlog.created_at) }}</span>
          </p>
        </div>
        <div class="card-actions">
          <button @click="preview(vlog)" title="预览"><i class="fas fa-eye"></i></button>
          <button @click="download(vlog)" title="下载" v-if="vlog.video_path"><i class="fas fa-download"></i></button>
          <button @click="share(vlog)" title="分享"><i class="fas fa-share-alt"></i></button>
          <button @click="remove(vlog.id)" title="删除" class="danger"><i class="fas fa-trash"></i></button>
        </div>
      </div>
    </div>

    <div v-if="previewing" class="modal-overlay" @click.self="closePreview">
      <div class="modal-content">
        <div class="modal-header">
          <h3>{{ previewing.title }}</h3>
          <button @click="closePreview" class="close-btn"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body">
          <video 
            v-if="previewing.video_path" 
            :src="getVideoUrl(previewing.video_path)" 
            controls 
            class="preview-video"
          ></video>
          <div v-else class="no-video">
            <i class="fas fa-video-slash"></i>
            <p>该Vlog没有视频文件</p>
          </div>
          
          <div class="preview-info" v-if="previewData">
            <div class="info-section" v-if="previewData.music">
              <h4><i class="fas fa-music"></i> 背景音乐</h4>
              <p>{{ previewData.music.title || previewData.music.original_name }}</p>
            </div>
            <div class="info-section" v-if="previewData.media_list">
              <h4><i class="fas fa-images"></i> 包含素材 ({{ previewData.media_list.length }})</h4>
              <div class="media-thumbs">
                <div v-for="(m, i) in previewData.media_list" :key="m.id" class="thumb">
                  <img v-if="m.media_type === 'image'" :src="getMediaUrl(m.filename)" />
                  <video v-else :src="getMediaUrl(m.filename)" muted></video>
                  <span>{{ i + 1 }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button @click="download(previewing)" v-if="previewing.video_path" class="btn-download">
            <i class="fas fa-download"></i> 下载
          </button>
          <button @click="share(previewing)" class="btn-share">
            <i class="fas fa-share-alt"></i> 分享
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { ElMessage } from 'element-plus';
import { tourismApi } from '@/api/tourismApi';

const vlogs = ref([]);
const previewing = ref(null);
const previewData = ref(null);

const getVideoUrl = (filename) => `/uploads/videos/${filename}`;
const getMediaUrl = (filename) => `/uploads/${filename}`;

const getFirstMediaThumb = (vlog) => {
  return '';
};

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString('zh-CN');
};

const fetchVlogs = async () => {
  try {
    const data = await tourismApi.getVlogList();
    vlogs.value = Array.isArray(data) ? data : [];
  } catch (err) {
    console.error('获取Vlog列表失败:', err);
    vlogs.value = [];
  }
};

const preview = async (vlog) => {
  previewing.value = vlog;
  previewData.value = null;
  
  try {
    previewData.value = await tourismApi.getVlogDetail(vlog.id);
  } catch (err) {
    console.error('获取Vlog详情失败:', err);
  }
};

const closePreview = () => {
  previewing.value = null;
  previewData.value = null;
};

const download = (vlog) => {
  if (!vlog.video_path) {
    ElMessage.warning('该Vlog没有视频文件');
    return;
  }
  
  const a = document.createElement('a');
  a.href = getVideoUrl(vlog.video_path);
  a.download = `${vlog.title}.webm`;
  a.click();
};

const share = async (vlog) => {
  const url = `${window.location.origin}/uploads/videos/${vlog.video_path}`;
  
  if (navigator.share) {
    try {
      await navigator.share({
        title: vlog.title,
        text: '看看我制作的旅行Vlog！',
        url: url
      });
    } catch (err) {
      console.log('分享取消');
    }
  } else {
    try {
      await navigator.clipboard.writeText(url);
      ElMessage.success('链接已复制到剪贴板！');
    } catch (err) {
      prompt('复制以下链接进行分享：', url);
    }
  }
};

const remove = async (id) => {
  if (!confirm('确定要删除这个Vlog吗？')) return;
  
  try {
    await fetch(`/api/vlog/${id}`, { method: 'DELETE' });
    fetchVlogs();
    ElMessage.success('删除成功');
  } catch (err) {
    console.error('删除失败:', err);
    ElMessage.error('删除失败');
  }
};

onMounted(() => {
  fetchVlogs();
});

defineExpose({ fetchVlogs });
</script>

<style scoped>
.my-vlogs {
  max-width: 100%;
}

.empty {
  text-align: center;
  padding: 40px 10px;
  color: #808080;
}

.empty i {
  font-size: 2.2rem;
  color: #b2ebf2;
  margin-bottom: 8px;
}

.empty p {
  font-size: 0.9rem;
  margin-bottom: 3px;
}

.empty .hint {
  font-size: 0.75rem;
  color: #b0bec5;
}

.vlog-list {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.vlog-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.card-thumb {
  position: relative;
  width: 100%;
  height: 100px;
  background: #000;
  cursor: pointer;
  overflow: hidden;
}

.card-thumb video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumb-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #e0f7fa;
}

.thumb-placeholder i {
  font-size: 1.8rem;
  color: #00bcd4;
}

.play-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.3);
  opacity: 0;
  transition: opacity 0.3s ease;
}

.card-thumb:hover .play-overlay {
  opacity: 1;
}

.play-overlay i {
  font-size: 2rem;
  color: white;
}

.card-body {
  padding: 8px 10px;
}

.card-body h3 {
  color: #006064;
  font-size: 0.85rem;
  margin-bottom: 4px;
}

.meta {
  display: flex;
  gap: 8px;
  font-size: 0.7rem;
  color: #607d8b;
}

.meta span {
  display: flex;
  align-items: center;
  gap: 3px;
}

.card-actions {
  display: flex;
  gap: 4px;
  padding: 0 10px 8px;
}

.card-actions button {
  flex: 1;
  background: #e0f7fa;
  border: none;
  padding: 6px;
  border-radius: 4px;
  cursor: pointer;
  color: #006064;
  font-size: 0.75rem;
}

.card-actions button:hover {
  background: #00bcd4;
  color: white;
}

.card-actions button.danger:hover {
  background: #f44336;
}

.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 16px;
  border-bottom: 1px solid #e0f7fa;
}

.modal-header h3 {
  color: #006064;
  font-size: 0.95rem;
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.1rem;
  color: #808080;
  cursor: pointer;
}

.modal-body {
  padding: 16px;
}

.preview-video {
  width: 100%;
  border-radius: 8px;
  margin-bottom: 16px;
}

.no-video {
  text-align: center;
  padding: 30px;
  color: #808080;
}

.no-video i {
  font-size: 2.2rem;
  color: #b2ebf2;
  margin-bottom: 8px;
}

.preview-info {
  margin-top: 12px;
}

.info-section {
  margin-bottom: 14px;
}

.info-section h4 {
  color: #006064;
  font-size: 0.85rem;
  margin-bottom: 6px;
}

.info-section h4 i {
  margin-right: 4px;
}

.info-section p {
  color: #607d8b;
  font-size: 0.8rem;
}

.media-thumbs {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
}

.thumb {
  position: relative;
  width: 50px;
  height: 38px;
  border-radius: 4px;
  overflow: hidden;
}

.thumb img,
.thumb video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumb span {
  position: absolute;
  bottom: 2px;
  left: 2px;
  background: rgba(0, 188, 212, 0.9);
  color: white;
  padding: 1px 3px;
  border-radius: 2px;
  font-size: 0.55rem;
}

.modal-footer {
  display: flex;
  gap: 8px;
  padding: 12px 16px;
  border-top: 1px solid #e0f7fa;
}

.btn-download, .btn-share {
  flex: 1;
  padding: 8px;
  border: none;
  border-radius: 15px;
  cursor: pointer;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
}

.btn-download {
  background: linear-gradient(135deg, #4caf50, #45a049);
  color: white;
}

.btn-share {
  background: linear-gradient(135deg, #00bcd4, #0097a7);
  color: white;
}
</style>