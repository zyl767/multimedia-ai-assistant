<template>
  <div class="timeline-section">
    <div v-if="media.length === 0" class="empty-state">
      <i class="fas fa-images"></i>
      <p>还没有照片，快去相册上传吧！</p>
    </div>
    
    <div v-else class="timeline">
      <div 
        v-for="(group, date) in groupedMedia" 
        :key="date" 
        class="timeline-group"
      >
        <div class="timeline-date">
          <span>{{ date }}</span>
          <div class="date-line"></div>
        </div>
        
        <div class="media-grid">
          <div 
            v-for="item in group" 
            :key="item.id"
            class="media-card"
          >
            <div class="media-thumbnail">
              <img v-if="item.media_type === 'image'" :src="getMediaUrl(item.filename)" :alt="item.original_name" />
              <video v-else :src="getMediaUrl(item.filename)" controls></video>
            </div>
            <div class="media-info">
              <p class="media-location"><i class="fas fa-map-marker-alt"></i> {{ item.location_name || '未标记位置' }}</p>
              <p class="media-desc">{{ item.ai_description || '暂无文案' }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  media: {
    type: Array,
    default: () => []
  }
});

const groupedMedia = computed(() => {
  const groups = {};
  
  props.media.forEach(item => {
    const date = item.travel_date || item.upload_time;
    const dateObj = new Date(date);
    const timestamp = dateObj.getTime();
    const formattedDate = dateObj.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    if (!groups[formattedDate]) {
      groups[formattedDate] = { items: [], timestamp };
    }
    groups[formattedDate].items.push(item);
  });
  
  const sortedDates = Object.keys(groups).sort((a, b) => groups[a].timestamp - groups[b].timestamp);
  
  const sortedGroups = {};
  sortedDates.forEach(date => {
    sortedGroups[date] = groups[date].items;
  });
  
  return sortedGroups;
});

const getMediaUrl = (filename) => `/uploads/${filename}`;
</script>

<style scoped>
.timeline-section {
  max-width: 100%;
}

.empty-state {
  text-align: center;
  padding: 50px 10px;
  color: #808080;
}

.empty-state i {
  font-size: 2.5rem;
  color: #b2ebf2;
  margin-bottom: 10px;
}

.empty-state p {
  font-size: 0.9rem;
}

.timeline-group {
  margin-bottom: 25px;
}

.timeline-date {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}

.timeline-date span {
  background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
  color: white;
  padding: 6px 14px;
  border-radius: 15px;
  font-size: 0.8rem;
  font-weight: 500;
}

.date-line {
  flex: 1;
  height: 2px;
  background: #b2ebf2;
  margin-left: 12px;
}

.media-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.media-card {
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
  background: white;
}

.media-thumbnail {
  width: 100%;
  height: 90px;
  overflow: hidden;
}

.media-thumbnail img,
.media-thumbnail video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.media-info {
  padding: 10px;
}

.media-location {
  color: #0097a7;
  font-size: 0.75rem;
  margin-bottom: 3px;
}

.media-desc {
  color: #607d8b;
  font-size: 0.7rem;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
</style>