<template>
  <div class="knowledge-explorer">
    <div class="search-box">
      <input 
        v-model="searchQuery" 
        @input="handleSearch"
        type="text" 
        placeholder="搜索景点、酒店、美食..."
        class="search-input"
      >
      <button @click="handleSearch" class="search-btn">
        <i class="fas fa-search"></i>
      </button>
    </div>

    <div v-if="searchResults" class="search-results">
      <div v-if="searchResults.cities.length > 0" class="result-section">
        <h4>🏙️ 城市</h4>
        <div v-for="city in searchResults.cities" :key="city" class="result-item" @click="selectCity(city)">
          {{ city }}
        </div>
      </div>
      <div v-if="searchResults.attractions.length > 0" class="result-section">
        <h4>📍 景点</h4>
        <div v-for="(item, idx) in searchResults.attractions.slice(0, 5)" :key="idx" class="result-item">
          <span class="result-city">{{ item.city }}</span>
          <span class="result-name">{{ item.名称 }}</span>
          <span class="result-price">{{ item.票价 }}</span>
        </div>
      </div>
      <div v-if="searchResults.hotels.length > 0" class="result-section">
        <h4>🏨 酒店</h4>
        <div v-for="(item, idx) in searchResults.hotels.slice(0, 5)" :key="idx" class="result-item">
          <span class="result-city">{{ item.city }}</span>
          <span class="result-name">{{ item.名称 }}</span>
          <span class="result-tag">{{ item.档次 }}</span>
        </div>
      </div>
      <div v-if="searchResults.foods.length > 0" class="result-section">
        <h4>🍜 美食</h4>
        <div v-for="(item, idx) in searchResults.foods.slice(0, 5)" :key="idx" class="result-item">
          <span class="result-city">{{ item.city }}</span>
          <span class="result-name">{{ item.名称 }}</span>
          <span class="result-price">{{ item.人均 }}</span>
        </div>
      </div>
      <div v-if="searchResults.routes.length > 0" class="result-section">
        <h4>🚄 路线</h4>
        <div v-for="(item, idx) in searchResults.routes.slice(0, 5)" :key="idx" class="result-item">
          <span>{{ item.from_city }} → {{ item.to_city }}</span>
          <span class="result-price">{{ item.price }}元</span>
        </div>
      </div>
    </div>

    <div v-if="!searchQuery" class="browse-sections">
      <div class="category-tabs">
        <button 
          v-for="tab in categories" 
          :key="tab.id" 
          :class="['category-tab', { active: activeCategory === tab.id }]"
          @click="switchCategory(tab.id)"
        >
          {{ tab.icon }} {{ tab.name }}
        </button>
      </div>

      <div v-if="activeCategory === 'all'" class="section">
        <h4>🏙️ 热门城市</h4>
        <div class="city-grid">
          <span 
            v-for="city in cities" 
            :key="city" 
            :class="['city-tag', { active: selectedCity === city }]"
            @click="selectCity(city)"
          >
            {{ city }}
          </span>
        </div>
      </div>

      <div class="section">
        <h4>💰 预算等级</h4>
        <div class="budget-list">
          <div v-for="(config, level) in budgetLevels" :key="level" class="budget-item">
            <span class="budget-name">{{ level }}</span>
            <span class="budget-range">
              {{ config.min === 0 ? '0' : config.min.toLocaleString() }}-{{ config.max === Infinity ? '∞' : config.max.toLocaleString() }}元
            </span>
            <span class="budget-days">{{ config.days }}天</span>
          </div>
        </div>
      </div>

      <div class="section">
        <h4>🍃 季节推荐</h4>
        <div class="season-list">
          <div v-for="(cities, season) in seasonCities" :key="season" class="season-item">
            <span class="season-name">{{ season }}</span>
            <div class="season-cities">
              <span v-for="city in cities" :key="city" class="mini-tag">{{ city }}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="section">
        <h4>🚄 热门路线</h4>
        <div class="route-list">
          <div v-for="(route, idx) in trainRoutes.slice(0, 8)" :key="idx" class="route-item">
            <span class="route-cities">{{ route.from_city }} → {{ route.to_city }}</span>
            <span class="route-price">{{ route.price }}元</span>
            <span class="route-duration">{{ route.duration }}</span>
          </div>
        </div>
      </div>
    </div>

    <div v-if="activeCategory === 'hotels' && allHotels.length > 0" class="all-list">
      <h4>🏨 全部住宿 ({{ allHotels.length }}家)</h4>
      <div v-for="(hotel, idx) in allHotels" :key="idx" class="all-card">
        <div class="all-header">
          <span class="all-city">{{ hotel.city }}</span>
          <span :class="['all-tag', hotel.档次]">{{ hotel.档次 }}</span>
        </div>
        <div class="all-name">{{ hotel.名称 }}</div>
        <div class="all-meta">
          <span>💰 {{ hotel.价格 }}</span>
          <span>📍 {{ hotel.位置 }}</span>
        </div>
      </div>
    </div>

    <div v-if="activeCategory === 'attractions' && allAttractions.length > 0" class="all-list">
      <h4>📍 全部景点 ({{ allAttractions.length }}个)</h4>
      <div v-for="(attraction, idx) in allAttractions" :key="idx" class="all-card">
        <div class="all-header">
          <span class="all-city">{{ attraction.city }}</span>
          <span class="all-rating">⭐ {{ attraction.评分 }}</span>
        </div>
        <div class="all-name">{{ attraction.名称 }}</div>
        <div class="all-meta">
          <span>🎫 {{ attraction.票价 }}</span>
          <span>🏷️ {{ attraction.特色 }}</span>
        </div>
      </div>
    </div>

    <div v-if="activeCategory === 'foods' && allFoods.length > 0" class="all-list">
      <h4>🍜 全部美食 ({{ allFoods.length }}家)</h4>
      <div v-for="(food, idx) in allFoods" :key="idx" class="all-card">
        <div class="all-header">
          <span class="all-city">{{ food.city }}</span>
          <span class="all-price">{{ food.人均 }}</span>
        </div>
        <div class="all-name">{{ food.名称 }}</div>
        <div class="all-desc">{{ food.特色 }}</div>
      </div>
    </div>

    <div v-if="selectedCity && cityInfo" class="city-detail">
      <button @click="selectedCity = null" class="close-detail">✕</button>
      <h4>📍 {{ selectedCity }} 详细信息</h4>
      
      <div v-if="cityInfo.景点" class="detail-panel">
        <h5>景点</h5>
        <div v-for="attraction in cityInfo.景点" :key="attraction.名称" class="attraction-card">
          <div class="attraction-header">
            <span class="attraction-name">{{ attraction.名称 }}</span>
            <span class="attraction-rating">⭐ {{ attraction.评分 }}</span>
          </div>
          <div class="attraction-meta">
            <span>🎫 {{ attraction.票价 }}</span>
            <span>⏰ {{ attraction.开放时间 }}</span>
            <span>⏳ {{ attraction.游玩时长 }}</span>
          </div>
          <p class="attraction-desc">{{ attraction.特色 }}</p>
        </div>
      </div>

      <div v-if="cityInfo.酒店" class="detail-panel">
        <h5>酒店</h5>
        <div v-for="hotel in cityInfo.酒店" :key="hotel.名称" class="hotel-card">
          <div class="hotel-header">
            <span class="hotel-name">{{ hotel.名称 }}</span>
            <span :class="['hotel-level', hotel.档次]">{{ hotel.档次 }}</span>
          </div>
          <div class="hotel-meta">
            <span>💰 {{ hotel.价格 }}</span>
            <span>📍 {{ hotel.位置 }}</span>
          </div>
        </div>
      </div>

      <div v-if="cityInfo.美食" class="detail-panel">
        <h5>美食</h5>
        <div v-for="food in cityInfo.美食" :key="food.名称" class="food-card">
          <div class="food-header">
            <span class="food-name">{{ food.名称 }}</span>
            <span class="food-price">{{ food.人均 }}</span>
          </div>
          <p class="food-desc">{{ food.特色 }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { tourismApi } from '@/api/tourismApi'

const searchQuery = ref('')
const searchResults = ref(null)
const cities = ref([])
const budgetLevels = ref({})
const seasonCities = ref({})
const trainRoutes = ref([])
const selectedCity = ref(null)
const cityInfo = ref(null)

const categories = [
  { id: 'all', name: '全部', icon: '📋' },
  { id: 'hotels', name: '住宿', icon: '🏨' },
  { id: 'attractions', name: '景点', icon: '📍' },
  { id: 'foods', name: '美食', icon: '🍜' }
]

const activeCategory = ref('all')
const allHotels = ref([])
const allAttractions = ref([])
const allFoods = ref([])

const loadData = async () => {
  try {
    const [cityRes, budgetRes, seasonRes, routeRes] = await Promise.all([
      tourismApi.getCities(),
      tourismApi.getBudgetLevels(),
      tourismApi.getSeasonCities(),
      tourismApi.getTrainRoutes()
    ])
    cities.value = cityRes.cities
    budgetLevels.value = budgetRes.budget_levels
    seasonCities.value = seasonRes.season_cities
    trainRoutes.value = routeRes.routes
  } catch (err) {
    console.error('加载知识库数据失败:', err)
  }
}

const loadAllHotels = async () => {
  try {
    const res = await tourismApi.getAllHotels()
    allHotels.value = res.hotels
  } catch (err) {
    console.error('加载酒店数据失败:', err)
  }
}

const loadAllAttractions = async () => {
  try {
    const res = await tourismApi.getAllAttractions()
    allAttractions.value = res.attractions
  } catch (err) {
    console.error('加载景点数据失败:', err)
  }
}

const loadAllFoods = async () => {
  try {
    const res = await tourismApi.getAllFoods()
    allFoods.value = res.foods
  } catch (err) {
    console.error('加载美食数据失败:', err)
  }
}

const switchCategory = async (category) => {
  activeCategory.value = category
  selectedCity.value = null
  cityInfo.value = null
  
  if (category === 'hotels' && allHotels.value.length === 0) {
    await loadAllHotels()
  } else if (category === 'attractions' && allAttractions.value.length === 0) {
    await loadAllAttractions()
  } else if (category === 'foods' && allFoods.value.length === 0) {
    await loadAllFoods()
  }
}

const handleSearch = async () => {
  if (!searchQuery.value.trim()) {
    searchResults.value = null
    return
  }
  try {
    searchResults.value = await tourismApi.searchKnowledge(searchQuery.value)
  } catch (err) {
    console.error('搜索失败:', err)
  }
}

const selectCity = async (city) => {
  selectedCity.value = city
  searchQuery.value = ''
  searchResults.value = null
  try {
    cityInfo.value = await tourismApi.getCityInfo(city)
  } catch (err) {
    console.error('获取城市信息失败:', err)
  }
}

onMounted(() => {
  loadData()
})
</script>

<style scoped>
.knowledge-explorer {
  padding: 10px;
}

.search-box {
  display: flex;
  margin-bottom: 12px;
}

.search-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #e2e8f0;
  border-radius: 6px 0 0 6px;
  font-size: 0.85rem;
  outline: none;
}

.search-input:focus {
  border-color: #00bcd4;
}

.search-btn {
  padding: 8px 12px;
  background: #00bcd4;
  color: white;
  border: none;
  border-radius: 0 6px 6px 0;
  cursor: pointer;
}

.search-btn:hover {
  background: #0097a7;
}

.search-results {
  max-height: 400px;
  overflow-y: auto;
}

.result-section {
  margin-bottom: 12px;
}

.result-section h4 {
  font-size: 0.8rem;
  color: #64748b;
  margin-bottom: 6px;
}

.result-item {
  display: flex;
  align-items: center;
  padding: 6px 8px;
  background: #f8fafc;
  border-radius: 4px;
  margin-bottom: 4px;
  font-size: 0.75rem;
  cursor: pointer;
}

.result-item:hover {
  background: #e0f2fe;
}

.result-city {
  color: #00bcd4;
  margin-right: 6px;
}

.result-name {
  flex: 1;
  color: #334155;
}

.result-price,
.result-tag {
  color: #64748b;
  font-size: 0.7rem;
}

.browse-sections {
  max-height: 500px;
  overflow-y: auto;
}

.section {
  margin-bottom: 16px;
}

.section h4 {
  font-size: 0.85rem;
  color: #006064;
  margin-bottom: 8px;
}

.city-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.city-tag {
  padding: 5px 10px;
  background: #e0f2fe;
  color: #0369a1;
  border-radius: 12px;
  font-size: 0.75rem;
  cursor: pointer;
}

.city-tag:hover,
.city-tag.active {
  background: #00bcd4;
  color: white;
}

.budget-list,
.season-list,
.route-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.budget-item {
  display: flex;
  align-items: center;
  padding: 6px 8px;
  background: #fef3c7;
  border-radius: 4px;
  font-size: 0.75rem;
}

.budget-name {
  font-weight: 600;
  color: #b45309;
  width: 60px;
}

.budget-range {
  flex: 1;
  color: #64748b;
}

.budget-days {
  color: #059669;
  font-size: 0.7rem;
}

.season-item {
  padding: 6px 8px;
  background: #ecfdf5;
  border-radius: 4px;
}

.season-name {
  display: block;
  font-weight: 600;
  color: #065f46;
  font-size: 0.8rem;
  margin-bottom: 4px;
}

.season-cities {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.mini-tag {
  padding: 2px 6px;
  background: #d1fae5;
  color: #059669;
  border-radius: 8px;
  font-size: 0.65rem;
}

.route-item {
  display: flex;
  align-items: center;
  padding: 6px 8px;
  background: #f0f9ff;
  border-radius: 4px;
  font-size: 0.75rem;
}

.route-cities {
  flex: 1;
  color: #0369a1;
}

.route-price {
  color: #059669;
  margin-right: 8px;
}

.route-duration {
  color: #64748b;
  font-size: 0.7rem;
}

.city-detail {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px dashed #cbd5e1;
}

.close-detail {
  float: right;
  border: none;
  background: none;
  color: #94a3b8;
  cursor: pointer;
  font-size: 0.8rem;
}

.city-detail h4 {
  font-size: 0.9rem;
  color: #006064;
  margin-bottom: 10px;
}

.detail-panel {
  margin-bottom: 12px;
}

.detail-panel h5 {
  font-size: 0.8rem;
  color: #475569;
  margin-bottom: 6px;
}

.attraction-card,
.hotel-card,
.food-card {
  padding: 8px;
  background: #f8fafc;
  border-radius: 6px;
  margin-bottom: 6px;
}

.attraction-header,
.hotel-header,
.food-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.attraction-name,
.hotel-name,
.food-name {
  font-weight: 600;
  color: #1e293b;
  font-size: 0.8rem;
}

.attraction-rating {
  color: #f59e0b;
  font-size: 0.75rem;
}

.hotel-level {
  font-size: 0.65rem;
  padding: 1px 6px;
  border-radius: 4px;
}

.hotel-level.豪华 {
  background: #fef3c7;
  color: #b45309;
}

.hotel-level.舒适 {
  background: #dbeafe;
  color: #1d4ed8;
}

.hotel-level.经济 {
  background: #d1fae5;
  color: #059669;
}

.attraction-meta,
.hotel-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 0.7rem;
  color: #64748b;
  margin-bottom: 4px;
}

.attraction-desc,
.food-desc {
  font-size: 0.7rem;
  color: #64748b;
  margin: 0;
}

.food-price {
  color: #059669;
  font-size: 0.75rem;
}

.category-tabs {
  display: flex;
  gap: 4px;
  margin-bottom: 12px;
}

.category-tab {
  flex: 1;
  padding: 6px 8px;
  background: #f1f5f9;
  border: none;
  border-radius: 4px;
  font-size: 0.75rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2px;
}

.category-tab:hover {
  background: #e0f2fe;
}

.category-tab.active {
  background: #00bcd4;
  color: white;
}

.all-list {
  max-height: 500px;
  overflow-y: auto;
}

.all-list h4 {
  font-size: 0.85rem;
  color: #006064;
  margin-bottom: 10px;
}

.all-card {
  padding: 8px;
  background: #f8fafc;
  border-radius: 6px;
  margin-bottom: 6px;
}

.all-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.all-city {
  color: #00bcd4;
  font-size: 0.7rem;
}

.all-tag {
  font-size: 0.65rem;
  padding: 1px 6px;
  border-radius: 4px;
}

.all-tag.豪华 {
  background: #fef3c7;
  color: #b45309;
}

.all-tag.舒适 {
  background: #dbeafe;
  color: #1d4ed8;
}

.all-tag.经济 {
  background: #d1fae5;
  color: #059669;
}

.all-name {
  font-weight: 600;
  color: #1e293b;
  font-size: 0.8rem;
  margin-bottom: 4px;
}

.all-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 0.7rem;
  color: #64748b;
}

.all-rating {
  color: #f59e0b;
  font-size: 0.75rem;
}

.all-price {
  color: #059669;
  font-size: 0.75rem;
}

.all-desc {
  font-size: 0.7rem;
  color: #64748b;
  margin: 0;
}
</style>
