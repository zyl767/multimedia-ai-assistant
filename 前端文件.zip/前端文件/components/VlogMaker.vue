<template>
  <div class="vlog-maker">
    <div class="maker-header">
      <h2><i class="fas fa-video"></i> 制作Vlog</h2>
      <p>选择素材和背景音乐，生成精彩旅行视频</p>
    </div>

    <div class="maker-layout">
      <div class="left-panel">
        <div class="panel-section">
          <h3><i class="fas fa-images"></i> 选择素材</h3>
          <div class="media-select" v-if="media.length > 0">
            <div 
              v-for="item in media" 
              :key="item.id"
              :class="['select-item', { active: isSelected(item.id) }]"
              @click="toggleMedia(item)"
            >
              <img v-if="item.media_type === 'image'" :src="getMediaUrl(item.filename)" />
              <video v-else :src="getMediaUrl(item.filename)" muted></video>
              <span class="check" v-if="isSelected(item.id)"><i class="fas fa-check"></i></span>
              <span class="order" v-if="isSelected(item.id)">{{ getSelectedIndex(item.id) + 1 }}</span>
            </div>
          </div>
          <div v-else class="empty-hint">请先在相册上传照片</div>
        </div>

        <div class="panel-section">
          <div class="section-header">
            <h3><i class="fas fa-music"></i> 背景音乐</h3>
            <button class="btn-upload-music" @click="triggerMusicUpload">
              <i class="fas fa-upload"></i> 上传音乐
            </button>
          </div>
          <input type="file" ref="musicFileInput" accept="audio/*" class="hidden-file-input" @change="handleMusicUpload" />
          <div class="music-select">
            <div 
              v-for="music in musicList" 
              :key="music.id"
              :class="['music-item', { active: selectedMusic === music.id }]"
              @click="selectMusic(music)"
            >
              <div class="music-icon"><i class="fas fa-music"></i></div>
              <div class="music-info">
                <p class="music-title">{{ music.title || music.original_name }}</p>
                <p class="music-artist">{{ music.artist || '未知' }}</p>
              </div>
              <button 
                class="play-btn" 
                @click.stop="togglePlay"
                v-if="selectedMusic === music.id"
              >
                <i :class="playing ? 'fas fa-pause' : 'fas fa-play'"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="right-panel">
        <div class="panel-section">
          <h3><i class="fas fa-list"></i> 已选素材 ({{ selectedMedia.length }})</h3>
          <div v-if="selectedMedia.length === 0" class="empty-hint">请从左侧选择素材</div>
          <div v-else class="selected-list">
            <div v-for="(item, idx) in selectedMedia" :key="item.id" class="selected-item">
              <span class="item-order">{{ idx + 1 }}</span>
              <img v-if="item.media_type === 'image'" :src="getMediaUrl(item.filename)" />
              <video v-else :src="getMediaUrl(item.filename)" muted></video>
              <div class="item-detail">
                <p>{{ item.original_name }}</p>
                <p class="item-loc">{{ item.location_name || '未标记' }}</p>
              </div>
              <div class="item-actions">
                <button @click="moveUp(idx)" :disabled="idx === 0"><i class="fas fa-arrow-up"></i></button>
                <button @click="moveDown(idx)" :disabled="idx === selectedMedia.length - 1"><i class="fas fa-arrow-down"></i></button>
                <button @click="removeMedia(idx)"><i class="fas fa-times"></i></button>
              </div>
            </div>
          </div>
        </div>

        <div class="panel-section">
          <h3><i class="fas fa-cog"></i> 视频设置</h3>
          <div class="settings">
            <div class="setting">
              <label>每张照片显示</label>
              <input type="range" v-model.number="photoDuration" min="1" max="10" />
              <span>{{ photoDuration }}秒</span>
            </div>
          </div>
        </div>

        <div class="panel-section">
          <button 
            class="btn-generate" 
            @click="generateVideo" 
            :disabled="selectedMedia.length === 0 || generating"
          >
            <i class="fas fa-magic"></i> 
            {{ generating ? `生成中... ${progress}%` : '生成视频' }}
          </button>
        </div>

        <div v-if="videoUrl" class="panel-section">
          <h3><i class="fas fa-film"></i> 视频预览</h3>
          <video :src="videoUrl" controls class="video-preview"></video>
          <div class="video-actions">
            <button class="btn-download" @click="downloadVideo">
              <i class="fas fa-download"></i> 下载视频
            </button>
          </div>
        </div>
      </div>
    </div>

    <canvas ref="canvas" style="display:none;"></canvas>
    <canvas ref="canvasPlayer" style="display:none;"></canvas>
    <audio ref="audioPlayer"></audio>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { tourismApi } from '@/api/tourismApi';

const props = defineProps({
  media: { type: Array, default: () => [] },
  musicList: { type: Array, default: () => [] }
});

const canvas = ref(null);
const audioPlayer = ref(null);

const selectedMedia = ref([]);
const selectedMusic = ref(null);
const playing = ref(false);
const photoDuration = ref(3);
const generating = ref(false);
const progress = ref(0);
const videoUrl = ref('');
const videoBlob = ref(null);
const musicFileInput = ref(null);

const emit = defineEmits(['update:musicList']);

const getMediaUrl = (filename) => `/uploads/${filename}`;
const getMusicUrl = (musicId) => `/api/album/music/${musicId}/stream`;

const isSelected = (id) => selectedMedia.value.some(m => m.id === id);
const getSelectedIndex = (id) => selectedMedia.value.findIndex(m => m.id === id);

const toggleMedia = (item) => {
  const idx = selectedMedia.value.findIndex(m => m.id === item.id);
  if (idx > -1) {
    selectedMedia.value.splice(idx, 1);
  } else {
    selectedMedia.value.push({ ...item });
  }
};

const removeMedia = (idx) => {
  selectedMedia.value.splice(idx, 1);
};

const moveUp = (idx) => {
  if (idx === 0) return;
  const temp = selectedMedia.value[idx];
  selectedMedia.value[idx] = selectedMedia.value[idx - 1];
  selectedMedia.value[idx - 1] = temp;
};

const moveDown = (idx) => {
  if (idx === selectedMedia.value.length - 1) return;
  const temp = selectedMedia.value[idx];
  selectedMedia.value[idx] = selectedMedia.value[idx + 1];
  selectedMedia.value[idx + 1] = temp;
};

const selectMusic = (music) => {
  if (selectedMusic.value === music.id) {
    selectedMusic.value = null;
    if (playing.value) {
      audioPlayer.value.pause();
      playing.value = false;
    }
  } else {
    selectedMusic.value = music.id;
    audioPlayer.value.src = getMusicUrl(music.id);
  }
};

const togglePlay = () => {
  if (playing.value) {
    audioPlayer.value.pause();
    playing.value = false;
  } else {
    audioPlayer.value.play();
    playing.value = true;
  }
};

const triggerMusicUpload = () => {
  musicFileInput.value.click();
};

const handleMusicUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  try {
    const result = await tourismApi.uploadMusic(file);
    ElMessage.success('音乐上传成功');
    
    const newMusic = {
      id: result.id,
      title: result.title || file.name.replace(/\.[^/.]+$/, ''),
      original_name: file.name,
      artist: result.artist || '用户上传',
      duration: result.duration || 0,
      url: null
    };
    
    emit('update:musicList', [...props.musicList, newMusic]);
  } catch (err) {
    console.error('上传失败:', err);
    ElMessage.error('音乐上传失败');
  }
  
  e.target.value = '';
};

const generateVideo = async () => {
  if (selectedMedia.value.length === 0) {
    ElMessage.warning('请先选择素材！');
    return;
  }
  
  generating.value = true;
  progress.value = 0;
  videoUrl.value = '';
  
  const cv = canvas.value;
  const ctx = cv.getContext('2d');
  cv.width = 800;
  cv.height = 450;
  
  const videoStream = cv.captureStream(30);
  let audioStream = null;
  let audioContext = null;
  let musicSource = null;
  
  if (selectedMusic.value) {
    try {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const musicUrl = getMusicUrl(selectedMusic.value);
      const response = await fetch(musicUrl);
      if (!response.ok) throw new Error('音频下载失败');
      const arrayBuffer = await response.arrayBuffer();
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      
      musicSource = audioContext.createBufferSource();
      musicSource.buffer = audioBuffer;
      musicSource.loop = true;
      
      const gainNode = audioContext.createGain();
      gainNode.gain.value = 0.3;
      
      const dest = audioContext.createMediaStreamDestination();
      musicSource.connect(gainNode);
      gainNode.connect(dest);
      gainNode.connect(audioContext.destination);
      
      musicSource.start();
      audioStream = dest.stream;
    } catch (err) {
      console.error('音频加载失败:', err);
      ElMessage.warning('背景音乐加载失败，将生成无声音视频');
    }
  }
  
  const tracks = [...videoStream.getVideoTracks()];
  if (audioStream) {
    tracks.push(...audioStream.getAudioTracks());
  }
  const combinedStream = new MediaStream(tracks);
  
  const mimeTypes = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm', 'video/mp4'];
  let selectedMimeType = '';
  for (const mimeType of mimeTypes) {
    if (MediaRecorder.isTypeSupported(mimeType)) {
      selectedMimeType = mimeType;
      break;
    }
  }
  
  const recorder = new MediaRecorder(combinedStream, {
    mimeType: selectedMimeType || undefined
  });
  
  const chunks = [];
  recorder.ondataavailable = (e) => {
    if (e.data.size > 0) chunks.push(e.data);
  };
  
  recorder.onstop = () => {
    if (musicSource) musicSource.stop();
    if (audioContext) audioContext.close();
    
    if (chunks.length === 0) {
      ElMessage.error('视频生成失败');
      generating.value = false;
      return;
    }
    
    videoBlob.value = new Blob(chunks, { type: selectedMimeType || 'video/webm' });
    videoUrl.value = URL.createObjectURL(videoBlob.value);
    generating.value = false;
    ElMessage.success('视频生成成功');
  };
  
  const mediaResources = await Promise.all(selectedMedia.value.map(async (item) => {
    if (item.media_type === 'image') {
      return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => resolve({ ...item, resource: img });
        img.onerror = () => resolve({ ...item, resource: null });
        img.src = getMediaUrl(item.filename);
      });
    } else {
      return new Promise((resolve) => {
        const video = document.createElement('video');
        video.crossOrigin = 'anonymous';
        video.muted = true;
        video.onloadeddata = () => resolve({ ...item, resource: video });
        video.onerror = () => resolve({ ...item, resource: null });
        video.src = getMediaUrl(item.filename);
      });
    }
  }));
  
  const totalDuration = mediaResources.reduce((sum, item) => {
    return sum + (item.media_type === 'video' ? 5 : photoDuration.value);
  }, 0) * 1000;
  
  recorder.start();
  
  const startTime = performance.now();
  
  for (const media of mediaResources) {
    const mediaDuration = (media.media_type === 'video' ? 5 : photoDuration.value) * 1000;
    const start = performance.now();
    
    if (media.media_type === 'video' && media.resource) {
      media.resource.currentTime = 0;
      media.resource.play();
    }
    
    while (performance.now() - start < mediaDuration) {
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, cv.width, cv.height);
      
      if (media.resource) {
        if (media.media_type === 'image') {
          const scale = Math.max(cv.width / media.resource.width, cv.height / media.resource.height);
          const w = media.resource.width * scale;
          const h = media.resource.height * scale;
          const x = (cv.width - w) / 2;
          const y = (cv.height - h) / 2;
          ctx.drawImage(media.resource, x, y, w, h);
        } else {
          const scale = Math.max(cv.width / media.resource.videoWidth, cv.height / media.resource.videoHeight);
          const w = media.resource.videoWidth * scale;
          const h = media.resource.videoHeight * scale;
          const x = (cv.width - w) / 2;
          const y = (cv.height - h) / 2;
          ctx.drawImage(media.resource, x, y, w, h);
        }
      }
      
      drawInfoBar(ctx, cv, media);
      
      const elapsed = performance.now() - startTime;
      progress.value = Math.round((elapsed / totalDuration) * 100);
      
      await new Promise(r => setTimeout(r, 40));
    }
    
    if (media.media_type === 'video' && media.resource) {
      media.resource.pause();
    }
  }
  
  recorder.stop();
};

const drawInfoBar = (ctx, cv, item) => {
  ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.fillRect(0, cv.height - 80, cv.width, 80);
  
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px "Noto Sans SC"';
  ctx.textAlign = 'left';
  ctx.fillText(item.location_name || '旅行时光', 30, cv.height - 45);
  
  if (item.travel_date) {
    ctx.fillStyle = '#b2ebf2';
    ctx.font = '16px "Noto Sans SC"';
    ctx.fillText(item.travel_date, 30, cv.height - 18);
  }
  
  if (item.ai_description) {
    ctx.fillStyle = '#e0f7fa';
    ctx.font = '14px "Noto Sans SC"';
    ctx.textAlign = 'right';
    const text = item.ai_description.length > 40 
      ? item.ai_description.substring(0, 40) + '...' 
      : item.ai_description;
    ctx.fillText(text, cv.width - 30, cv.height - 25);
  }
};

const downloadVideo = () => {
  if (!videoUrl.value) return;
  const a = document.createElement('a');
  a.href = videoUrl.value;
  a.download = `travel-vlog-${Date.now()}.webm`;
  a.click();
};

const saveVlog = async () => {
  if (!videoBlob.value) return;
  
  const title = prompt('请输入Vlog标题:', '我的旅行Vlog');
  if (!title) return;
  
  const formData = new FormData();
  formData.append('file', videoBlob.value, `vlog-${Date.now()}.webm`);
  
  try {
    const uploadRes = await fetch('/api/vlog/upload', {
      method: 'POST',
      body: formData
    });
    const uploadData = await uploadRes.json();
    
    await tourismApi.createVlog({
      title: title,
      media_ids: selectedMedia.value.map(m => m.id),
      music_id: selectedMusic.value,
      video_path: uploadData.filename
    });
    
    ElMessage.success('Vlog保存成功！');
  } catch (err) {
    console.error('保存失败:', err);
    ElMessage.error('保存失败，请重试');
  }
};
</script>

<style scoped>
.vlog-maker { max-width: 100%; }
.maker-header { text-align: center; margin-bottom: 15px; }
.maker-header h2 { font-size: 1.2rem; color: #006064; margin-bottom: 4px; }
.maker-header p { color: #00838f; font-size: 0.8rem; }
.maker-layout { display: flex; flex-direction: column; gap: 15px; }
.panel-section { background: rgba(255,255,255,0.8); border-radius: 8px; padding: 12px; margin-bottom: 10px; }
.section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.section-header h3 { color: #006064; font-size: 0.9rem; margin: 0; }
.section-header h3 i { margin-right: 4px; }
.btn-upload-music { background: #00bcd4; color: white; border: none; padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; cursor: pointer; display: flex; align-items: center; gap: 4px; }
.btn-upload-music:hover { background: #0097a7; }
.hidden-file-input { display: none; }
.empty-hint { text-align: center; padding: 15px; color: #808080; font-size: 0.8rem; }

.media-select { display: grid; grid-template-columns: repeat(auto-fill, minmax(70px, 1fr)); gap: 6px; max-height: 180px; overflow-y: auto; }
.select-item { position: relative; width: 100%; height: 55px; border-radius: 6px; overflow: hidden; cursor: pointer; border: 2px solid transparent; }
.select-item img, .select-item video { width: 100%; height: 100%; object-fit: cover; }
.select-item.active { border-color: #00bcd4; }
.check { position: absolute; top: 2px; right: 2px; background: #00bcd4; color: white; width: 14px; height: 14px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.5rem; }
.order { position: absolute; bottom: 2px; left: 2px; background: rgba(0,188,212,0.9); color: white; padding: 1px 4px; border-radius: 3px; font-size: 0.6rem; }

.music-select { max-height: 180px; overflow-y: auto; }
.music-item { display: flex; align-items: center; gap: 8px; padding: 8px; border-radius: 6px; cursor: pointer; margin-bottom: 4px; border: 2px solid transparent; }
.music-item:hover { background: #e0f7fa; }
.music-item.active { background: #b2ebf2; border-color: #00bcd4; }
.music-icon { background: linear-gradient(135deg, #00bcd4, #0097a7); color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; }
.music-info { flex: 1; }
.music-title { color: #006064; font-size: 0.8rem; margin: 0; }
.music-artist { color: #607d8b; font-size: 0.7rem; margin: 0; }
.play-btn { background: #00bcd4; color: white; border: none; width: 24px; height: 24px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; }

.selected-list { max-height: 220px; overflow-y: auto; }
.selected-item { display: flex; align-items: center; gap: 8px; padding: 6px; background: #e0f7fa; border-radius: 6px; margin-bottom: 4px; }
.item-order { background: #00bcd4; color: white; width: 18px; height: 18px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.65rem; font-weight: bold; }
.selected-item img, .selected-item video { width: 40px; height: 32px; object-fit: cover; border-radius: 4px; }
.item-detail { flex: 1; }
.item-detail p { margin: 0; color: #006064; font-size: 0.75rem; }
.item-loc { color: #607d8b !important; font-size: 0.65rem !important; }
.item-actions { display: flex; gap: 3px; }
.item-actions button { background: white; border: none; width: 22px; height: 22px; border-radius: 4px; cursor: pointer; color: #006064; font-size: 0.65rem; }
.item-actions button:disabled { opacity: 0.3; }
.item-actions button:hover:not(:disabled) { background: #00bcd4; color: white; }

.settings { display: flex; flex-direction: column; gap: 8px; }
.setting { display: flex; align-items: center; gap: 8px; }
.setting label { width: 80px; color: #006064; font-size: 0.8rem; }
.setting input[type="range"] { flex: 1; }
.setting span { width: 40px; text-align: right; color: #0097a7; font-size: 0.8rem; }

.btn-generate { width: 100%; padding: 10px; border: none; border-radius: 18px; background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%); color: white; font-size: 0.9rem; cursor: pointer; transition: all 0.3s ease; }
.btn-generate:disabled { opacity: 0.5; }
.btn-generate:not(:disabled):hover { transform: translateY(-1px); box-shadow: 0 3px 12px rgba(0,188,212,0.4); }

.video-preview { width: 100%; border-radius: 8px; margin-bottom: 10px; }
.video-actions { display: flex; gap: 8px; }
.btn-download, .btn-save { flex: 1; padding: 8px; border: none; border-radius: 15px; cursor: pointer; font-size: 0.8rem; }
.btn-download { background: linear-gradient(135deg, #4caf50, #45a049); color: white; }
.btn-save { background: linear-gradient(135deg, #00bcd4, #0097a7); color: white; }
</style>