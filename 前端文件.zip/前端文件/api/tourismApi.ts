import request from './request'

export interface ChatResult {
  type: 'card' | 'knowledge' | 'text'
  title: string
  content: string
  metadata?: Record<string, string>
}

export interface ChatResponse {
  success: boolean
  query: string
  intents: string[]
  city?: string
  season?: string
  results: ChatResult[]
  sources: string[]
  count: number
}

export interface UploadResponse {
  success: boolean
  filename: string
  total_chars: number
  total_chunks: number
  message: string
}

export interface ImageUploadResponse {
  success: boolean
  message: string
  id: string
  filename: string
  url: string
}

export interface ImageInfo {
  id: string
  filename: string
  url: string
  upload_time: string
}

export interface GenerateVideoRequest {
  image_ids: string[]
  title?: string
}

export interface GenerateVideoResponse {
  success: boolean
  message: string
  video_url?: string
}

export interface MediaItem {
  id: string
  filename: string
  original_name: string
  media_type: string
  upload_time: string
  travel_date?: string
  location_name?: string
  latitude?: number
  longitude?: number
  ai_description?: string
  thumbnail?: string
}

export interface UpdateMediaRequest {
  travel_date?: string
  location_name?: string
  latitude?: number
  longitude?: number
  ai_description?: string
}

export interface MusicItem {
  id: string
  filename: string
  original_name: string
  title?: string
  artist?: string
  duration?: number
  upload_time: string
  url?: string
}

export interface VlogItem {
  id: string
  title: string
  media_count: number
  music_id?: string
  video_path?: string
  created_at: string
}

export interface VlogDetail {
  id: string
  title: string
  media_list: MediaItem[]
  music?: MusicItem
  video_path?: string
  created_at: string
}

export interface CreateVlogRequest {
  title: string
  media_ids: string[]
  music_id?: string
  video_path?: string
}

export interface StatsResponse {
  document_count: number
}

export interface Attraction {
  名称: string
  票价: string
  开放时间: string
  游玩时长: string
  评分: string
  介绍?: string
  特色?: string
}

export interface Hotel {
  名称: string
  档次: string
  价格: string
  位置: string
}

export interface Food {
  名称: string
  特色: string
  人均: string
  推荐菜: string[]
}

export interface DayPlan {
  day: number
  morning: string
  afternoon: string
  evening: string
  attractions: Attraction[]
  meals: string[]
}

export interface TransportOption {
  type: string
  duration: string
  price_range?: string
  price?: string
  frequency: string
  train?: string
}

export interface TransportInfo {
  from: string
  to: string
  options: TransportOption[]
}

export interface TravelPlanResponse {
  success: boolean
  city?: string
  season?: string
  days?: number
  budget?: number
  budget_level?: string
  from_city?: string
  title?: string
  description?: string
  daily_plan?: DayPlan[]
  hotels?: Hotel[]
  foods?: Food[]
  recommendations?: Array<{
    city: string
    description: string
    rating: string
    price_range: string
    best_attractions: string[]
    special_food: string[]
    budget_friendly?: boolean
  }>
  tips?: string[]
  transport?: TransportInfo[]
  budget_details?: {
    transport: number
    accommodation: number
    attractions: number
    food: number
    total: number
  }
}

export const tourismApi = {
  chat: (query: string, n_results?: number): Promise<ChatResponse> => {
    return request.post('/chat', { query, n_results })
  },

  upload: (file: File): Promise<UploadResponse> => {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  uploadImage: (file: File): Promise<ImageUploadResponse> => {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/image/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  getImages: (): Promise<{ images: ImageInfo[] }> => {
    return request.get('/images')
  },

  deleteImage: (imageId: string): Promise<{ success: boolean; message: string }> => {
    return request.delete(`/image/${imageId}`)
  },

  generateVideo: (request: GenerateVideoRequest): Promise<GenerateVideoResponse> => {
    return request.post('/video/generate', request)
  },

  stats: (): Promise<StatsResponse> => {
    return request.get('/stats')
  },

  health: (): Promise<{ status: string; message: string }> => {
    return request.get('/health')
  },

  plan: (query: string): Promise<TravelPlanResponse> => {
    return request.post('/plan', { query })
  },

  uploadMedia: (file: File): Promise<{ message: string; id: string; media_type: string; thumbnail?: string }> => {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/album/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  getMediaList: (): Promise<MediaItem[]> => {
    return request.get('/album/media')
  },

  getMediaDetail: (mediaId: string): Promise<MediaItem> => {
    return request.get(`/album/media/${mediaId}`)
  },

  updateMedia: (mediaId: string, data: UpdateMediaRequest): Promise<{ message: string }> => {
    return request.put(`/album/media/${mediaId}`, data)
  },

  deleteMedia: (mediaId: string): Promise<{ message: string }> => {
    return request.delete(`/album/media/${mediaId}`)
  },

  generateDescription: (mediaId: string, data: { location_name?: string; travel_date?: string; additional_context?: string }): Promise<{ message: string; description: string }> => {
    return request.post(`/album/media/${mediaId}/description`, data)
  },

  uploadMusic: (file: File): Promise<{ message: string; id: string; duration?: number }> => {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/album/music', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  getMusicList: (): Promise<MusicItem[]> => {
    return request.get('/album/music')
  },

  getMusicDetail: (musicId: string): Promise<MusicItem> => {
    return request.get(`/album/music/${musicId}`)
  },

  deleteMusic: (musicId: string): Promise<{ message: string }> => {
    return request.delete(`/album/music/${musicId}`)
  },

  createVlog: (data: CreateVlogRequest): Promise<{ message: string; id: string }> => {
    return request.post('/album/vlog', data)
  },

  getVlogList: (): Promise<VlogItem[]> => {
    return request.get('/album/vlogs')
  },

  getVlogDetail: (vlogId: string): Promise<VlogDetail> => {
    return request.get(`/album/vlog/${vlogId}`)
  },

  uploadVlogVideo: (file: File): Promise<{ message: string; filename: string }> => {
    const formData = new FormData()
    formData.append('file', file)
    return request.post('/album/vlog/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  deleteVlog: (vlogId: string): Promise<{ message: string }> => {
    return request.delete(`/album/vlog/${vlogId}`)
  },

  getCities: (): Promise<{ cities: string[] }> => {
    return request.get('/knowledge/cities')
  },

  getCityInfo: (cityName: string): Promise<any> => {
    return request.get(`/knowledge/city/${cityName}`)
  },

  getBudgetLevels: (): Promise<{ budget_levels: Record<string, { min: number; max: number; days: number }> }> => {
    return request.get('/knowledge/budget-levels')
  },

  getSeasonCities: (): Promise<{ season_cities: Record<string, string[]> }> => {
    return request.get('/knowledge/season-cities')
  },

  getTrainRoutes: (): Promise<{ routes: Array<{ from_city: string; to_city: string; price: number; duration: string; train: string }> }> => {
    return request.get('/knowledge/train-routes')
  },

  searchKnowledge: (query: string): Promise<{
    cities: string[]
    attractions: Array<{ city: string; 名称: string; 票价: string; 特色: string }>
    hotels: Array<{ city: string; 名称: string; 档次: string; 价格: string; 位置: string }>
    foods: Array<{ city: string; 名称: string; 特色: string; 人均: string }>
    routes: Array<{ from_city: string; to_city: string; price: number; duration: string }>
  }> => {
    return request.get(`/knowledge/search?query=${encodeURIComponent(query)}`)
  },

  getAllHotels: (): Promise<{ hotels: Array<{ city: string; 名称: string; 档次: string; 价格: string; 位置: string }> }> => {
    return request.get('/knowledge/all-hotels')
  },

  getAllAttractions: (): Promise<{ attractions: Array<{ city: string; 名称: string; 票价: string; 特色: string; 评分: string }> }> => {
    return request.get('/knowledge/all-attractions')
  },

  getAllFoods: (): Promise<{ foods: Array<{ city: string; 名称: string; 特色: string; 人均: string }> }> => {
    return request.get('/knowledge/all-foods')
  }
}